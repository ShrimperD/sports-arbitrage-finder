import { BettingTable } from '@/components/features/BettingTable';

export default function Home() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight">Arbitrage Opportunities</h2>
        <p className="text-muted-foreground">
          Track and analyze real-time betting opportunities across multiple bookmakers.
        </p>
      </div>

      <div className="flex gap-4 flex-col md:flex-row">
        <div className="flex-1 space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <div className="p-4 rounded-lg border bg-card">
              <div className="text-sm font-medium text-muted-foreground">Total Profit</div>
              <div className="text-2xl font-bold text-green-500">$1,234.56</div>
            </div>
            <div className="p-4 rounded-lg border bg-card">
              <div className="text-sm font-medium text-muted-foreground">Active Bets</div>
              <div className="text-2xl font-bold">12</div>
            </div>
            <div className="p-4 rounded-lg border bg-card">
              <div className="text-sm font-medium text-muted-foreground">Avg. ROI</div>
              <div className="text-2xl font-bold">2.8%</div>
            </div>
            <div className="p-4 rounded-lg border bg-card">
              <div className="text-sm font-medium text-muted-foreground">Success Rate</div>
              <div className="text-2xl font-bold">94%</div>
            </div>
          </div>

          <BettingTable />
        </div>
      </div>
    </div>
  );
}